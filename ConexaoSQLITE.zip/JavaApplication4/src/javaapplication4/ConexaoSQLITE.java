package javaapplication4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexaoSQLITE {
    private Connection conexao;
    public boolean conectar(){
        try {
            
            String url ="jdbc:sqlite:C:\\Users\\Windows\\Documents\\SQLITE_bases_dados.db" ;
            this.conexao=DriverManager.getConnection(url);
            
        } catch (SQLException e  ){
            System.err.println(e.getMessage());
            return false;
        }
        
        System.out.println("CONECTADO");
        return true;
    }
    public boolean desconectar(){
        try{
            if (this.conexao.isClosed()==false){
                this.conexao.close();
            }
        } catch (SQLException e ){
            System.err.println(e.getMessage());
            return false;
        }
        System.out.println("DESCONCTADO");
        return true;
    }
}
