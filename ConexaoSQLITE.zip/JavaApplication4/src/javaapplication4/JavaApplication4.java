package javaapplication4;
public class JavaApplication4 {
    public static void main(String[] args) {
        // TODO code application logic here
        ConexaoSQLITE conexaoSQLITE = new ConexaoSQLITE();
        conexaoSQLITE.conectar();
        conexaoSQLITE.desconectar();
    } 
    
}
